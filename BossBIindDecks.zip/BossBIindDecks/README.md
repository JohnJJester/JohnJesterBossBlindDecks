# JohnJesterBossBlindDecks
Adds 5 New vanilla inspired decks to the game based on the 5 final boss blinds!

Let me know if you run into any bugs!!!